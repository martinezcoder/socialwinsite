<?php

//  PROJECT HONEY POT ADDRESS DISTRIBUTION SCRIPT
//  For more information visit: http://www.projecthoneypot.org/
//  Copyright (C) 2004-2012, Unspam Technologies, Inc.
//  
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
//  02111-1307  USA
//  
//  If you choose to modify or redistribute the software, you must
//  completely disconnect it from the Project Honey Pot Service, as
//  specified under the Terms of Service Use. These terms are available
//  here:
//  
//  http://www.projecthoneypot.org/terms_of_service_use.php
//  
//  The required modification to disconnect the software from the
//  Project Honey Pot Service is explained in the comments below. To find the
//  instructions, search for:  *** DISCONNECT INSTRUCTIONS ***
//  
//  Generated On: Thu, 22 Nov 2012 00:43:51 -0800
//  For Domain: www.socialwin.es
//  
//  

//  *** DISCONNECT INSTRUCTIONS ***
//  
//  You are free to modify or redistribute this software. However, if
//  you do so you must disconnect it from the Project Honey Pot Service.
//  To do this, you must delete the lines of code below located between the
//  *** START CUT HERE *** and *** FINISH CUT HERE *** comments. Under the
//  Terms of Service Use that you agreed to before downloading this software,
//  you may not recreate the deleted lines or modify this software to access
//  or otherwise connect to any Project Honey Pot server.
//  
//  *** START CUT HERE ***
//  
define('__REQUEST_HOST', 'hpr6.projecthoneypot.org');
define('__REQUEST_PORT', '80');
define('__REQUEST_SCRIPT','/cgi/serve.php');
//  
//  *** FINISH CUT HERE ***
//  

define('__HPOT_TAG1',    '66723cc01395009f18d6ea39aad4cd80');
define('__HPOT_TAG2',    '7dfe692c7df857b58af2d060d01734e1');
define('__HPOT_TAG3',    '34aa2473d1aa4705f92165addfe297ff');

define('__CLASS_STYLE_1','doho');
define('__CLASS_STYLE_2','xuju');

define('__DIV1',         '77trapr1jud6');

define('__VANITY_L1',    'MEMBER OF PROJECT HONEY POT');
define('__VANITY_L2',    'Spam Harvester Protection Network');
define('__VANITY_L3',    'provided by Unspam');

define('__DOC_TYPE1',    '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">\n');
define('__HEAD1',        '<html>\n<head>\n');
define('__HEAD2',        '<title>Unadvised Probability Voluble</title>\n</head>\n');
define('__ROBOT1',       '<meta name="robots" content="noindex">\n<meta name="robots" content="noarchive,follow">\n');
define('__NOCOLLECT1',   '<meta name="no-email-collection" content="/">\n');
define('__TOP1',         '<body>\n<div align="center">\n');
define('__EMAIL1A',      '<a href="mailto:');
define('__EMAIL1B',      '" style="display: none;">');
define('__EMAIL1C',      '</a>');
define('__EMAIL2A',      '<a href="mailto:');
define('__EMAIL2B',      '" style="display:none;">');
define('__EMAIL2C',      '</a>');
define('__EMAIL3A',      '<a style="display: none;" href="mailto:');
define('__EMAIL3B',      '">');
define('__EMAIL3C',      '</a>');
define('__EMAIL4A',      '<a style="display:none;" href="mailto:');
define('__EMAIL4B',      '">');
define('__EMAIL4C',      '</a>');
define('__EMAIL5A',      '<a href="mailto:');
define('__EMAIL5B',      '"></a>');
define('__EMAIL5C',      '..');
define('__EMAIL6A',      '<span style="display: none;"><a href="mailto:');
define('__EMAIL6B',      '">');
define('__EMAIL6C',      '</a></span>');
define('__EMAIL7A',      '<span style="display:none;"><a href="mailto:');
define('__EMAIL7B',      '">');
define('__EMAIL7C',      '</a></span>');
define('__EMAIL8A',      '<!-- <a href="mailto:');
define('__EMAIL8B',      '">');
define('__EMAIL8C',      '</a> -->');
define('__EMAIL9A',      '<div id="'.__DIV1.'"><a href="mailto:');
define('__EMAIL9B',      '">');
define('__EMAIL9C',      '</a></div><br><script language="JavaScript" type="text/javascript">document.getElementById(\''.__DIV1.'\').innerHTML=\'\';</script>');
define('__EMAIL10A',     '<a href="mailto:');
define('__EMAIL10B',     '"><!-- ');
define('__EMAIL10C',     ' --></a>');
define('__LEGAL1',       '');
define('__LEGAL2',       '\n');
define('__STYLE1',       '\n<style>a.'.__CLASS_STYLE_1.'{color:#FFF;font:bold 10px arial,sans-serif;text-decoration:none;}</style>');
define('__VANITY1',      '<table cellspacing="0"cellpadding="0"border="0"style="background:#999;width:230px;"><tr><td valign="top"style="padding: 1px 2px 5px 4px;border-right:solid 1px #CCC;"><span style="font:bold 30px arial,sans-serif;color:#666;top:0px;position:relative;">@</span></td><td valign="top" align="left" style="padding:3px 0 0 4px;"><a href="http://www.projecthoneypot.org/" class="'.__CLASS_STYLE_1.'">'.__VANITY_L1.'</a><br><a href="http://www.unspam.com"class="'.__CLASS_STYLE_1.'">'.__VANITY_L2.'<br>'.__VANITY_L3.'</a></td></tr></table>\n');
define('__BOTTOM1',      '</div>\n</body>\n</html>\n');


function getLegalContent() { return '<table cellspacing="0" cellpadding="0" border="0">\n<tr>\n<td><div style="font-family: courier, monospace;">&nbsp; <br>&nbsp;<br>T&#104;<br>to<br>&#111;&#116;<br>We<br>re<br>ag<br>th<span style="display: none">tonic supper treasury youthful geometric</span><br>no<br>W&#101;<br><br>&nbsp; <br>&nbsp;<br>Sp<br>No<br>sp<br>pr<br>a&#117;<br><br>Em<br>It<br>a<span style="display: none">supporter</span>l<br>h<span style="display: none">kilometre owls hon basis hogs</span>a<br>st<br>va<br>st<br>a&#103;<br><br>&nbsp; <br>&nbsp;<br>Ea<br>ag<br>&#40;"<br>th<br>s&#117;<br>&#97;n<br>of<br>an<br>&#83;&#101;<br>th<br><br><b><span style="color:#FFF;">o</span></b>&nbsp;<br>&nbsp;<br>Y&#111;<br>ma<br>a&#98;<br>Vi<br><br>VI<br>&#80;A<br>SU<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>e <br>&nbsp;y<br>he<br>bs<br>ad<br>en<br>&#101;m<br>n-<br>bs<br><br>&nbsp; <br><br>ec<br>n-<br>&#105;&#100;<br>og<br>to<br><br>ai<br>&nbsp;i<br>on<br>s <br>o&#114;<br>lu<br>or<br>r&#101;<br><br><b><span style="color:#FFF;">c</span></b>&nbsp;<br><br>ch<br>a&#105;<br>Ju<br>e<span style="color:#FFF;">h</span><br>ch<br>&#100; <br><span style="color:#FFF;">e</span>f<br>y <br>&#114;v<br>e<span style="color:#FFF;">k</span><br><br>&nbsp; <br><br>u <br>&#121; <br>us<br>si<br><br>SI<br>RT<br>BS<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>we<br>ou<br>r <br>i<span style="display: none">dilemma</span>t<br>&nbsp;&#116;<br>ts<br>.<span style="color:#FFF;">p</span><br>&#116;r<br>it<br><br><b><span style="color:#FFF;">k</span><span style="color:#FFF;">g</span></b><br><br>ia<br>H&#117;<br>er<br>ra<br>m<span style="display: none">alkaline weapon</span>a<br><br>l <br>s <br>e.<br>a <br>ag<br>e <br>in<br>em<br><br>&nbsp; <br><br>&nbsp;p<br>ns<br>di<br>re<br>&nbsp;l<br>pe<br>ed<br>ac<br>ic<br>ab<br><br>&nbsp;<b><span style="color:#FFF;">g</span></b><br><br>co<span style="display: none">multivalent</span><br>a&#112;<br>e.<br>to<br><br>TO<br>Y <br>EQ<br></div></td>\n<td><div style="font-family: courier, monospace;"><b><span style="color:#FFF;">g</span></b>&nbsp;<br><br>&#98;s<br>&nbsp;s<br>te<br>e <br>he<br>&nbsp;o<br>Th<br>an<br>e.<br><br>&nbsp; <br><br>l <br>ma<br>s&#44;<br>ms<br>&#116;i<br><br>&#97;d<br>re<br>&nbsp;Y<br>va<br>&#101;,<br>&#111;f<br>g <br>en<br><br>&nbsp;<b><span style="color:#FFF;">g</span></b><br><br>&#97;r<br>t <br>&#99;i<br>gi<br>aw<br>r&#102;<br>er<br>t&#105;<br>&#101;.<br>ov<br><br><b><span style="color:#FFF;">k</span></b>&nbsp;<br><br>ns<span style="display: none">wordforword failure</span><br>pe<br>&nbsp;T<br>r&#115;<br><br>RS<br>OR<br>&#85;E<span style="display: none">clothes ridiculous folly atonal satin</span><br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>it<br>ub<span style="display: none">axiomatic</span><br>rm<br>yo<br>&#109; <br>f <br>e <br>sf<br><br><br>&nbsp; <br><br>re<span style="display: none">adventure dizzy lifestyle</span><br>n <br>&nbsp;b<br>&nbsp;d<br>ca<br><br>dr<br>co<br>ou<br>&#108;u<br>&nbsp;a<br>&nbsp;t<br>&#116;h<br>t <br><br>&nbsp; <br><br>&#116;y<br>th<br>al<br>s<span style="display: none">closefitting tissue brownbag</span>t<br>s <br>or<br>al<br>on<br>&nbsp;Y<br>&#101; <br><br><b><span style="color:#FFF;">f</span><span style="color:#FFF;">s</span></b><br><br>en<br>ar<br>he<br>&nbsp;a<br><br>&nbsp;&#65;<br>&nbsp;S<br>N&#84;<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>e <br>j&#101;<br>s <br>u <br>&#99;a<br>th<br>ac<br>er<br><br><br>&nbsp; <br><br>&#115;t<br>V<span style="display: none">psychologist</span>&#105;<br>ot<span style="display: none">quiet offshore</span><br>es<br>ll<br><br>e<span style="display: none">warning piano doublebarreled that</span>&#115;<br>gn<br>&nbsp;a<br>e <br>n&#100;<br>&#104;e<br>is<br>an<br><br>&nbsp; <br><br>&nbsp;a<br>e <br><span style="color:#FFF;">k</span>A<br>er<br>ar<br>me<br>&nbsp;a<br><span style="color:#FFF;">c</span>b<br>ou<br>a&#103;<br><br>&nbsp; <br><br>t <br>&nbsp;s<br>&nbsp;I<br>&#103;r<br><br>GR<br>&#69;N<br>&nbsp;B<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>f&#114;<br>ct<br>go<br>ac<br>re<br>e <br>ce<br>ab<br><br><br>&nbsp; <br><br>ri<br>si<br>s&#44;<br>ig<br>y.<br><br>&#115;e<br>iz<br>ck<br>no<br>/&#111;<br>&#115;e<br>&nbsp;W<br>&#100; <br><br>&nbsp; <br><br>gr<br>ot<br>ct<br>&#101;&#100;<br>e<span style="color:#FFF;">p</span><br>d <br>nd<br>&#114;&#111;<br>&nbsp;c<br>re<br><br>&nbsp; <br><br>to<br>om<br>de<br>ee<br><br>EE<br>DI<br>RE<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp;<b><span style="color:#FFF;">d</span></b><br><br>om<br>&nbsp;&#116;<br>ve<br>ce<br>fu<br>in<br>ss<br>le<br><br><br>&nbsp;<b>S</b><br><br>c&#116;<br>to<br>&nbsp;i<br>ne<br><br><br>s <br>e&#100;<br>no<br>t<span style="color:#FFF;">i</span><br>r <br>&nbsp;a<br>eb<br>e&#120;<br><br>&nbsp; <br><br>e&#101;<br>he<br>io<br><span style="color:#FFF;">c</span>A<br>ap<br>en<br><span style="color:#FFF;">p</span>s<br>&#117;g<br>on<br>em<br><br><b><span style="color:#FFF;">f</span></b>&nbsp;<br><br>&nbsp;h<br>ew<br>nt<br>&nbsp;&#110;<br><br>&nbsp;T<br>NG<br>AC<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>&nbsp;w<br>o <br>rn<br>&#112;t<br>&#108;l<br>di<br>&nbsp;r<br>&nbsp;w<br><br><br><b>PE</b><br><br>io<br>&#114;s<br>n&#100;<br>d <br><br><br>&#111;n<br><span style="color:#FFF;">h</span>t<br>&#119;l<br>le<br>di<span style="display: none">shared amateur positive set rollon</span><br>d&#100;<br>si<br>pr<br><br>&nbsp; <br><br>s <br>r <br>&#110;"<br>dm<br>pl<br>ti<br>ta<br>ht<br>se<br>en<br><br>&nbsp; <br><br>a&#118;<br>&#104;&#101;<br>if<br>&#111;t<br><br>HA<br>&nbsp;A<br>H<span style="color:#FFF;">k</span><br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>hi<br>th<br>i&#110;<br>&nbsp;&#116;<br>y.<br>vi<br>i<span style="display: none">oversexed appetite sandpipers</span>g<br>i&#116;<br><br><br><b>C&#73;</b><br><br>ns<br>. <br>ex<br>t&#111;<br><br><br>&nbsp;&#116;<br>h&#97;<br>e&#100;<br>s&#115;<br>&#115;&#116;<br>r&#101;<br>te<br>e&#115;<br><br>&nbsp; <br><br>th<br>in<span style="display: none">natural narrow</span><br>) <br>in<br>ie<br>re<br>te<br>&nbsp;a<br>nt<br>t.<br><br>&nbsp; <br><br>in<br>re<br>ie<br>&nbsp;t<br><br>T<span style="color:#FFF;">p</span><br>&#78;Y<br>OF<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp;<b><span style="color:#FFF;">i</span></b><br><br>&#99;h<br>e <br>g <br>he<br>&nbsp;A<br>du<br>ht<br>ho<br><br><br><b>AL</b><br><br><span style="color:#FFF;">h</span>o<br>No<br>e&#114;<br>&nbsp;&#97;<br><br><br>hi<br>t <br>ge<br>&nbsp;t<br>ri<br>ss<br>\'s<br>sl<br><br>&nbsp; <br><br>at<br>&nbsp;c<br>sh<br>is<br>d <br>ly<br>&nbsp;c<br>&#103;a<br>&nbsp;t<br><br><br>&nbsp; <br><br>g <br>&nbsp;o<br>&#114; <br>o <br><br>HA<br>&nbsp;M<br><span style="color:#FFF;">a</span>T<span style="display: none">american</span><br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br><span style="color:#FFF;">c</span>y<br>fo<br>a<span style="display: none">dry caudate twopiece reputation crossing</span>c<br>&#115;e<br>ny<br>&#97;l<br>s <br>u&#116;<br><br><br>&nbsp;<b>&#76;</b><br><br>n <br>&#110;-<br>s,<br>cc<br><br><br>s <br>th<br>&nbsp;a<br>ha<br>bu<br>e<span style="display: none">careful nameless funereal godly senile</span>s<br>&nbsp;e<br>y <br><br>&nbsp; <br><br>&nbsp;a<br>on<br>a&#108;<br>t&#114;<br>to<br>&nbsp;w<br>ou<br>&#105;n<br>o <br><br><br>&nbsp; <br><br>&#121;o<br>n <br>is<br>us<br><br>RV<span style="display: none">bulbous</span><br>ES<br>HE<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp; <br><br>ou<br>ll<br>ce<br>&nbsp;t<br>&nbsp;N<br>&#40;s<br>gr<br>&nbsp;t<br><br><br><b>IC</b><br><br>a <br>Hu<br><span style="color:#FFF;">h</span>&#114;<br>es<br><br><br>s&#105;<br>es<br>&#110;d<br>n <br>ti<br>.<span style="color:#FFF;">e</span><br>ma<br>pr<br><br>&nbsp;<b>A</b><br><br>ny<br>&#110;e<br>l <br>at<br>&nbsp;&#97;<br>it<br>rt<br>s&#116;<br>e&#108;<br><br><br><b>RE</b><br><br>&#117;&#114;<br>th<br>&nbsp;u<br>e <br><br>ES<br>SA<br>S&#69;<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp;<b>T</b><br><br>&nbsp;a<br>&#111;w<br>ss<br>er<br>on<br>&#41; <br>an<br>&#104;e<br><br><br><b>EN</b><br><br>vi<br>ma<br>ob<br>s,<br><br><br>te<br>e <br>&nbsp;a<br>US<br>on<br>In<br>il<br>oh<br><br><b>P&#80;</b><br><br><span style="color:#FFF;">e</span>&#115;<br>ct<br>be<br>&#105;v<br>&#103;r<br>hi<br>s <br>&nbsp;h<br>ec<br><br><br><b>CO</b><br><br>&nbsp;I<br>is<br>&#110;i<br>th<br><br>TI<br>GE<br>&nbsp;T<br></div></td>\n<td><div style="font-family: courier, monospace;"><b>ER</b><br><br>cc<br>in<span style="display: none">relative economics imprudent aids</span><br>&nbsp;t<br>&#109;s<br>-H<br>wh<br>te<br><span style="color:#FFF;">t</span>&#101;<br><br><br><b>&#83;E</b><br><br>si<br>n <br>ot<br>&nbsp;r<br><br><br>&nbsp;a<br>em<br>gr<br><span style="color:#FFF;">c</span>$<br><span style="color:#FFF;">k</span>o<br>&#116;e<br>&nbsp;a<br>&#105;b<br><br><b>LI</b><br><br>u&#105;<br>io<br><span style="color:#FFF;">d</span>g<span style="display: none">flowers boss telephone</span><br>e <br>ee<br>n <br>wi<br>im<br>tr<br><br><br><b>RD</b><br><br>nt<br>&nbsp;p<br>qu<br>is<br><br>NG<br>(S<br>&#69;R<br></div></td>\n<td><div style="font-family: courier, monospace;"><b>MS</b><br><br>es<br>&#103; <br>o <br>&nbsp;&#97;<br>um<br>&#111;<span style="color:#FFF;">p</span><br>d <br>xp<br><br><br>&nbsp;<b>R</b><br><br>to<br>Vi<br>s,<br>ea<br><br><br>re<br>ai<br>ee<br>5&#48;<br>f <br>nt<br>&#100;d<br>it<br><br><b>CA</b><br><br>t,<br>n <br>ov<br>&#67;&#111;<br>me<br>th<br>th<br>&nbsp;i<br>on<br><br><br><b>S</b>&nbsp;<br><br>er<br>ag<br>el<br>&nbsp;a<br><br>,<span style="color:#FFF;">t</span><br>)<span style="color:#FFF;">s</span><br>MS<br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp;<b>A</b><br><br>&#115;&#101;<br>co<br>th<br>n&#100;<br>a&#110;<br>co<br>t&#111;<br>re<span style="display: none">colossal separation certified</span><br><br><br><b>ES</b><br><br>&#114;\'<br>si<br>&nbsp;c<br>d,<br><br><br><span style="color:#FFF;">a</span>c<br>l <br>&nbsp;t<br>.<span style="display: none">routine viridescent</span>&nbsp;<br>th<br>&#105;&#111;<br>re<br>ed<br><br><b>BL</b><br><br>&nbsp;a<br>wi<br>er<br>nt<br>nt<br>e<span style="color:#FFF;">o</span><br>in<br>n <br>ic<br><br><br><b>OF</b><br><br>ne<br>e <br>y <br>dd<br><br>G&#65;<br>TO<br>&nbsp;O<br></div></td>\n<td><div style="font-family: courier, monospace;"><b>ND</b><br><br>d<span style="color:#FFF;">h</span><br>nd<br>e <br><span style="color:#FFF;">p</span>c<br><span style="color:#FFF;">e</span>V<br>n&#116;<br>&nbsp;y<br>ss<br><br><br><b>TR</b><br><br>&#115; <br>&#116;o<br>ra<br>&nbsp;c<br><br><br>o&#110;<br>ad<br>ha<br>Yo<br>es<br>na<br>ss<br>.<br><br><b>E</b>&nbsp;<br><br>&#99;t<br>th<br>ne<br>a&#99;<br>s <br>Ad<br>&nbsp;t<br>co<br><span style="color:#FFF;">s</span>s<br><br><br>&nbsp;<b>V</b><br><br>t <br>&#40;t<br>ma<br>re<br><br>&#84;H<br><span style="color:#FFF;">c</span>T<br>F <br></div></td>\n<td><div style="font-family: courier, monospace;"><b><span style="color:#FFF;">h</span>C</b><br><br>th<br>&#105;t<br>We<br>o&#110;<br>i&#115;<br>ro<br>ou<br>&nbsp;w<br><br><br><b>IC</b><br><br>li<br>rs<br>wl<br>om<br><br><br>si<br>d&#114;<br>t <br>u <br>e <br>l <br>e&#115;<br><br><br><b>LA</b><br><br>io<br>&nbsp;o<br>&#100; <br>t <br>be<br>mi<br>he<br>&#110;n<br>&#101;r<br><br><br><b>I<span style="display: none">productive</span>S</b><br><br>Pr<br>he<br>tc<br>&#115;s<br><br>ER<br>HE<br>SE<br></div></td>\n<td><div style="font-family: courier, monospace;"><b>O<span style="display: none">affair nonunion triangular</span>&#78;</b><br><br>is<br>io<br>bs<br>&#100;i<br>it<br>ls<br>&nbsp;u<br>ri<br><br><br><b>TI</b><br><br>ce<br>&nbsp;i<br>er<br>pi<br><br><br>d&#101;<br>&#101;s<br>e&#97;<br>fu<br>ad<br>co<br>&nbsp;i<br><br><br><b>W<span style="color:#FFF;">c</span></b><br><br>n <br>r <br>by<br>(t<br>tw<br>n <br>&nbsp;A<br>ec<br>v&#105;<br><br><br><b>IT</b><br><br>ot<br>&nbsp;"<br>he<br>&nbsp;f<br><br>IN<br><span style="color:#FFF;">f</span>&#73;<br>RV<br></div></td>\n<td><div style="font-family: courier, monospace;"><b>D&#73;</b><br><br>&nbsp;a<br>ns<br>it<br>ti<br>or<br>, <br>nd<br>tt<br><br><br><b>ON</b><br><br>ns<br>nc<br>s,<br>le<span style="display: none">concrete child matter clinical</span><br><br><br>re<br>se<br>ch<br>rt<br>dr<br>l<span style="display: none">canned goldfinches drier</span>l<br>s <br><br><br><b>AN<span style="display: none">classroom strongminded protective bill ethereal</span></b><br><br>&#111;r<br>a<span style="display: none">religion investment jailer monitor powdery</span>r<br><span style="color:#FFF;">f</span>t<br>he<br>ee<br>S<span style="display: none">dungeon statuesque medal sack</span>t<br>dm<br>ti<br>&#99;e<br><br><br><b>OR</b><br><br>&#111;c<br>I&#100;<br>d <br>or<br><br>G,<br>DE<br>I&#67;<br></div></td>\n<td><div style="font-family: courier, monospace;"><b>TI</b><br><br>gr<br>. <br>e&#46;<br>on<br>s <br>&#97;&#117;<br>er<br>en<br><br><br><b>S</b>&nbsp;<br><br>e <br>lu<br>&nbsp;h<br>&nbsp;o<br><br><br>d <br>s <br>&nbsp;&#101;<br>he<br>es<br>ec<br>re<br><br><br><b>D</b>&nbsp;<br><br>&nbsp;p<br>i&#115;<br>he<br>&nbsp;"<br>n <br>at<br>in<br>o&#110;<br>&nbsp;o<br><br><br><b><span style="color:#FFF;">c</span>U</b><br><br>ol<br>en<br>to<br>&nbsp;&#97;<br><br>&nbsp;S<br>NT<br>E&#46;<br></div></td>\n<td><div style="font-family: courier, monospace;"><b>ON</b><br><br>ee<br>Th<br><span style="color:#FFF;">p</span>&#66;<br>s <br>to<br>th<br>&nbsp;t<br>&nbsp;p<span style="display: none">fantastic taxi</span><br><br><br><b>FO</b><br><br>to<br>de<br>ar<br>r <br><br><br>pr<br>ar<br>ma<br>r <br>se<br>ti<br>c&#111;<br><br><br><b>&#74;U</b><br><br>ro<br>in<br>&nbsp;l<br>Ad<br>A&#100;<br>e.<br>&nbsp;S<br><span style="color:#FFF;">a</span>&#119;<br>f<span style="color:#FFF;">c</span><br><br><br><b>SE</b><br><br>&nbsp;a<br>ti<br>&nbsp;y<br>ny<br><br>TO<br>IF<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><b>S</b>&nbsp;<br><br>me<br>e&#115;<br>y<span style="color:#FFF;">d</span><br>&#40;&#116;<br><span style="color:#FFF;">t</span>t<br>&#111;r<br>he<br>e&#114;<br><br><br><b>R<span style="color:#FFF;">c</span></b><br><br>&nbsp;a<br>&#44; <br>ve<br>ga<br><br><br>&#111;p<br>e <br>il<br>ag<br>s <br>o&#110;<br>gn<br><br><br><b>RI</b><br><br>ce<br>g <br>&#97;w<br>mi<br>mi<br>&nbsp;Y<br>ta<br>it<br>&#112;r<br><br><br>&nbsp;<b>A</b><br><br>dd<br>fi<br>ou<br>&nbsp;&#114;<br><br>RI<br>IE<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><b>O&#70;</b><br><br>nt<br>e <br>v&#105;<br>he<br>he<br>s <br><span style="color:#FFF;">a</span>&#84;<br>mi<br><br><br><b>NO</b><br><br>&#99;c<br>&#98;u<br>st<br>th<br><br><br>ri<br>p<span style="display: none">fluent organization suitable fax</span>r<br>&nbsp;a<br>re<br>su<br>, <br>iz<br><br><br><b>&#83;D</b><br><br>ed<br>fr<br>&nbsp;o<br>n <br>n <br>ou<br>te<br>h <br>oc<br><br><br><b>ND</b><br><br>re<br>er<br>r <br>ea<br><br>NG<br>R <br><br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp;<b>U</b><br><br>&nbsp;(<br>te<br>si<br>&nbsp;"<br>&nbsp;W<br>or<br>er<br>&#115;s<br><br><br><b>N-</b><br><br>&#101;s<br>t <br>e&#114;<br>er<br><br><br>et<br>ov<br>d&#100;<br>e <br>bs<br>ha<br>ed<br><br><br><b>IC</b><br><br>in<br>om<br>&#102; <br>St<br>St<br>&nbsp;c<br>. <br>br<br>e&#115;<br><br><br>&nbsp;<b>A</b><br><br>ss<br>")<br>In<br>so<br><br>,<span style="color:#FFF;">c</span><br>CO<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><b>SE</b><br><br>"t<br>r&#109;<br>&#116;i<br>&#84;e<br>eb<br>&nbsp;o<br>m&#115;<br>io<br><br><br><b>&#72;U</b><br><br>s <br>&#97;r<br>s,<br>&nbsp;c<br><br><br>ar<br>id<br>re<br>t&#104;<br>ta<br>rv<br>&nbsp;a<br><br><br><b>TI</b><br><br>g<span style="color:#FFF;">f</span><br>&nbsp;t<br>th<br>at<br>at<br>on<br>Yo<br>ea<br>&#115; <br><br><br><b>BU</b><br><br>&nbsp;&#114;<br>&nbsp;i<br>te<br>n.<br><br>TR<br>NS<br><br></div></td>\n<td><div style="font-family: courier, monospace;">&nbsp;<br><br>&#104;e<br>s <br>ng<br>r&#109;<br>si<br>th<br>&nbsp;o<br>n <br><br><br><b>MA</b><br><br>th<br>e <br>&nbsp;&#111;<br>on<br><br><br>y <br>ed<br>s&#115;<br>a&#116;<br>nt<br>es<br>s <br><br><br><b>O&#78;</b><br><br>br<span style="display: none">electricity</span><br>&#104;e<br>&#101; <br>e"<br>e <br>s&#101;<br>u <br>ch<br>re<br><br><br><b>SE</b><br><br>ec<br>f <br>rn<br><br><br>&#65;&#78;<br>TI<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>&nbsp;W<br>ar<br>&nbsp;(<br>s <br>te<br>er<br>f <br>&#111;f<br><br><br><b>N</b>&nbsp;<br><br>e <br>&#110;o<br>r <br>te<br><br><br>in<br>&nbsp;&#102;<br>&nbsp;t<br><span style="color:#FFF;">o</span>t<br>i&#97;<br>&#116;i<br>a <br><br><br>&nbsp;<br><br>ou<br>&nbsp;T<br>&#115;t<br>) <br>re<br>nt<br>co<br>es<br>ga<br><br><br><b><span style="color:#FFF;">h</span></b><br><br>o&#114;<br>we<br>et<br><br><br>&#83;&#70;<br>TU<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>eb<br>e <br>in<br>of<br>&nbsp;s<br>w&#105;<br>&#83;e<br>&nbsp;t<br><br><br><b>VI</b><br><br>We<br>&#116; <br>an<br>nt<br><br><br>te<br>&#111;r<br>he<br>he<br>ll<br>ng<br>vi<br><br><br><br><br>gh<br>er<br>&#97;t<br>fo<br>si<br>&nbsp;t<br>&#110;s<br>&nbsp;o<br>rd<br><br><br><br><br>d<span style="display: none">philosopher speaker couchant</span>e<br>&nbsp;s<br><span style="color:#FFF;">d</span>P<br><br><br>E&#82;<br>TE<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>&#115;i<br>in<br>&nbsp;a<br><span style="color:#FFF;">h</span>&#83;<br>ha<br>&#115;e<br>rv<br>he<br><br><br><b>SI</b><br><br>bs<br>li<br>y <br>&nbsp;f<br><br><br>ll<br>&nbsp;h<br><span style="color:#FFF;">t</span>W<span style="display: none">climate consumption coat</span><br>&nbsp;c<br>y <br>, <br>ol<br><br><br><br><br>&#116; <br>ms<br>e <br>&#114; <br>de<br>o <br>en<br>&#102; <br>&#105;n<br><br><br><br><br>&#100;.<br>&#117;s<br>ro<br><br><br>&#82;I<br>&#83; <br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>te<br>&nbsp;&#97;<br>ny<br>er<br>ll<br>&nbsp;m<br>ic<br>&nbsp;o<br><br><br><b>TO</b><br><br>it<br>m<span style="display: none">funny flaming</span>i<br>ot<br>ro<br><br><br>ec<br>um<br>eb<br>om<br>di<br>ga<span style="display: none">nutty</span><br>at<br><br><br><br><br>by<br>&nbsp;o<br>of<br>th<br>nt<br>th<br>t <br>th<br>g <br><br><br><br><br>&nbsp;&#65;<br>&#112;e<br>to<br><br><br>NG<br>A&#78;<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>"&#41;<br>dd<br>&nbsp;m<br>vi<br>&nbsp;b<br>ak<br>&#101; <br>w&#110;<br><br><br><b>RS</b><br><br>e <br>te<br>h&#101;<br>m<span style="color:#FFF;">f</span><br><br><br>tu<br>an<br>si<br>pi<br>mi<br>th<br>i&#111;<br><br><br><br><br>&nbsp;s<br>f<span style="color:#FFF;">e</span><br>&nbsp;r<br>e <br>s <br>e <br>to<br>es<br>a&#99;<br><br><br><br><br>n <br>&#99;t<br>co<br><br><br>&nbsp;T<br>&nbsp;A<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>&nbsp;i<br>it<br>an<br>ce<br>e<span style="color:#FFF;">o</span><br>es<br>ar<br>er<br><br><br>&nbsp;<br><br>ap<br>&#100; <br>r <br>th<br><br><br>al<span style="display: none">blackfish rating slender midsize</span><br>&nbsp;v<br>te<br>la<br>ni<br>e&#114;<br>n <br><br><br><br><br>uc<br>Se<br>es<br>We<br>en<br>ju<br>&nbsp;t<br>e <br>ti<br><br><br><br><br>e&#109;<br>&nbsp;p<br>l<span style="color:#FFF;">p</span><br><br><br>O <br>CC<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>&#115; <br>i&#111;<br>ne<br>")<br>&#99;o<br>&nbsp;&#117;<br>e<br>&nbsp;&#111;<br><br><br><br><br>pl<br>to<br>co<br>&#101; <br><br><br>&nbsp;p<br>is<br>&nbsp;c<br>ti<br>sh<span style="display: none">larboard productivity</span><br>in<br>of<br><br><br><br><br>&#104; <br>rv<br>&#105;d<br>bs<br>te<br>ri<br>h&#101;<br>Te<br>on<br><br><br><br><br>a&#105;<br>ot<br>&#97;d<br><br><br>A <br>EP<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>pr<br>n <br>r)<br>. <br>ns<br>se<br><br>&#102; <br><br><br><br><br>y <br>, <br>mp<br>We<br><br><br>&#114;o<br>it<br>on<br>o&#110;<br>es<br>g,<br>&nbsp;&#116;<br><br><br><br><br>&#112;a<br>ic<br>en<br>it<br>re<br>sd<span style="display: none">ferroelectric organic</span><br>&nbsp;v<br>rm<br>s <br><br><br><br><br>l <br>&#101;n<br>dr<br><br><br>TH<br>T&#65;<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>ov<br>to<br><span style="color:#FFF;">p</span>t<br>Pl<br>id<br><span style="color:#FFF;">c</span>o<br><br>th<br><br><br><br><br>t<span style="display: none">roseate repetition</span>o<br>we<br>ut<br>bs<br><br><br>pe<br>&#111;r<br>t&#97;<br>,<br><span style="color:#FFF;">p</span>t<br>&nbsp;a<br>h&#105;<br><br><br><br><br>r&#116;<br>e<br>ce<br>e <br>d <br>&#105;c<br>en<br>s <br>u&#110;<br><br><br><br><br>ad<br>ti<br>es<br><br><br>IR<br>&#78;C<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>i&#100;<br>&nbsp;a<br>he<br>ea<br>er<br>f<br><br>e<br><br><br><br><br><br>b<br>er<br>it<br><br><br>r&#116;<br>s<br>in<br><br>he<br>nd<br>s<br><br><br><br><br>y<br><br>&nbsp;o<br>as<br>in<br>t<span style="display: none">clammy</span>i<br>ue<br>of<br>de<br><br><br><br><br>dr<br>a&#108;<br>s.<br><br><br>D<br>E <br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br>ed<br>ny<br><br>se<br>&#101;d<br><br><br><br><br><br><br><br><br><br><br>e<br><br><br>y.<br><br>s<br><br><br>/o<br><br><br><br><br><br><br><br>f<br><br>to<br>on<br>&nbsp;i<br><br>r<br><br><br><br><br>es<br><br><br><br><br><br>AN<br><br></div></td>\n<td><div style="font-family: courier, monospace;"><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>r<br><br><br><br><br><br><br><br><br><br><br><br>&#110;<br><br><br><br><br><br><br>&#115;<br><br><br><br><br><br>D<br><br></div></td>\n</tr>\n</table>\n<br>'; }


?><?php 

// 
// PROXY SUPPORT
//  
// This honey pot script supports Proxies. If your webserver requires a proxy
// for outbound connections you may configure this honey pot's settings to use
// a proxy.
//
// For more information, visit: 
//     http://www.projecthoneypot.org/settings_help.php
//
//



function formatHTML($s) {
    return str_replace('\n',"\n",$s);
}

function getDocType()       { return formatHTML(__DOC_TYPE1); }
function getHeadHTML1()     { return formatHTML(__HEAD1); }
function getRobotHTML()     { return formatHTML(__ROBOT1); }
function getNoCollectHTML() { return formatHTML(__NOCOLLECT1); }
function getHeadHTML2()     { return formatHTML(__HEAD2); }
function getTopHTML()       { return formatHTML(__TOP1); }
function getEmailHTML($method,$m) { 
    switch ($method) {
    case 0: return "";
    case 1: return formatHTML(__EMAIL1A.$m.__EMAIL1B.$m.__EMAIL1C); 
    case 2: return formatHTML(__EMAIL2A.$m.__EMAIL2B.$m.__EMAIL2C); 
    case 3: return formatHTML(__EMAIL3A.$m.__EMAIL3B.$m.__EMAIL3C); 
    case 4: return formatHTML(__EMAIL4A.$m.__EMAIL4B.$m.__EMAIL4C); 
    case 5: return formatHTML(__EMAIL5A.$m.__EMAIL5B); 
    case 6: return formatHTML(__EMAIL6A.$m.__EMAIL6B.$m.__EMAIL6C); 
    case 7: return formatHTML(__EMAIL7A.$m.__EMAIL7B.$m.__EMAIL7C); 
    case 8: return formatHTML(__EMAIL8A.$m.__EMAIL8B.$m.__EMAIL8C); 
    case 9: return formatHTML(__EMAIL9A.$m.__EMAIL9B.$m.__EMAIL9C); 
    }
    return formatHTML(__EMAIL10A.$m.__EMAIL10B.$m.__EMAIL10C); 
}
function getLegalHTML()   { return formatHTML(__LEGAL1.(getLegalContent()).__LEGAL2); }
function getStyleHTML()   { return formatHTML(__STYLE1); }
function getVanityHTML()  { return formatHTML(__VANITY1); }
function getBottomHTML()  { return formatHTML(__BOTTOM1); }

function readSettings() {
    $settings      = NULL;
    $settings_file = dirname(__FILE__)."/phpot_settings.php";

    if (is_file($settings_file) && is_readable($settings_file)) {
        $fp = fopen($settings_file,"r");
        $contents = "";
        while (!feof($fp)) {
            $contents .= fread($fp, 8192);
        }
        fclose($fp);

        $lines = explode("\n",$contents);
        foreach ($lines as $line) {
            if (trim($line) !== "") {
                list ($setting, $value) = @explode(":",$line,2);
                switch ($setting) {
                case "proxy_host": 
                    $settings["sock_host"] = trim($value);
                    break;
                case "proxy_port":
                    $settings["sock_port"] = trim($value);
                    break;
                }
                if (trim($value) !== "") {
                    $settings[trim($setting)] = trim($value);
                }
            }
        }
    }

    if (isset($settings["proxy_host"]) && isset($settings["proxy_port"]) && !isset($settings["use_proxy"])) {
        $settings["use_proxy"] = "1";
    } else {
        $settings["use_proxy"] = "0";
    }

    if (isset($settings["proxy_user"]) && isset($settings["proxy_pass"]) && !isset($settings["proxy_auth"])) {
        $settings["proxy_auth"] = "basic";
    } else {
        $settings["proxy_auth"] = "none";
    }

    if (!isset($settings["sock_host"])) $settings["sock_host"] = __REQUEST_HOST;
    if (!isset($settings["sock_port"])) $settings["sock_port"] = __REQUEST_PORT;

    return $settings;
}

function performRequest($request) {
    $response = "";

    $settings = readSettings();

    if ($settings["use_proxy"] == "1") {
        // POST via proxy
        $post_url = "http://".__REQUEST_HOST.":".__REQUEST_PORT.__REQUEST_SCRIPT;

        $head  = "POST ".$post_url." HTTP/1.0\r\n";
        //$head .= "Host: ".__REQUEST_HOST."\r\n";
        $head .= "User-Agent: PHPot ".__HPOT_TAG2."\r\n";
        if ($settings["proxy_auth"] == "basic") {
            $head .= "Proxy-Authorization: Basic ".base64_encode($settings["proxy_user"].":".$settings["proxy_pass"])."\r\n";
        }
        $head .= "Cache-Control: no-store, no-cache\r\n";
        $head .= "Accept: */*\r\n";
        $head .= "Pragma: no-cache\r\n";
        $head .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $head .= "Content-Length: ".strlen($request)."\r\n";
        $head .= "Connection: close\r\n\r\n";

    } else {
        // POST directly
        $head  = "POST ".__REQUEST_SCRIPT." HTTP/1.1\r\n";
        $head .= "Host: ".__REQUEST_HOST."\r\n";
        $head .= "User-Agent: PHPot ".__HPOT_TAG2."\r\n";
        $head .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $head .= "Content-Length: ".strlen($request)."\r\n";
        $head .= "Connection: close\r\n\r\n";
    }
    
    $errno  = NULL;
    $errstr = NULL;
    $fd = @fsockopen ($settings["sock_host"], $settings["sock_port"], $errno, $errstr, 20);

    if (!$fd) {
        // Socket Error
        die("\n<BR>Unable to contact the Server. Are outbound connections disabled? (If a proxy is required for outbound traffic, you may configure the honey pot to use a proxy. For instructions, visit http://www.projecthoneypot.org/settings_help.php)<BR>\n");
        return "-1";
    } else {

        fputs($fd,$head.$request);
        while(!feof($fd)) {
            $response .= fgets($fd,4096);
        }
        fclose($fd);
    }

    return $response;
}

function prepareRequest() {
    $postvars          = array();
    $postvars["tag1"]  = __HPOT_TAG1;
    $postvars["tag2"]  = __HPOT_TAG2;
    $postvars["tag3"]  = __HPOT_TAG3;
    if (!($handle = fopen(__FILE__,"r"))) {
        die("\n<BR>Unable to read contents of ".__FILE__." for hashing<BR>\n");
        return -2;
    }
    $contents = "";
    while (!feof($handle)) {
        $contents .= fread($handle, 8192);
    }
    fclose($handle);
    $postvars["tag4"]   = md5(preg_replace("/[^a-zA-Z0-9]/","",$contents));
    $postvars["ip"]    = $_SERVER["REMOTE_ADDR"];
    $postvars["svrn"]  = $_SERVER["SERVER_NAME"];  
    $postvars["svp"]   = $_SERVER["SERVER_PORT"];  
    $postvars["svip"]  = isset($_SERVER["SERVER_ADDR"]) ? $_SERVER["SERVER_ADDR"] : "";
    $postvars["rquri"]   = isset($_SERVER["REQUEST_URI"]) ? $_SERVER["REQUEST_URI"] : "";
    $postvars["phpself"] = str_replace(' ','%20',$_SERVER["PHP_SELF"]);
    $postvars["version"] = "php-".phpversion();
    $postvars["sn"]     = str_replace(' ','%20',$_SERVER["SCRIPT_NAME"]);
    $postvars["ref"]    = isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : "";
    $postvars["uagnt"]  = isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : "";
    if (isset($_POST) && count($_POST) > 0) {
        $postvars["has_post"] = count($_POST);
        for (reset($_POST);list($k,$v) = each($_POST);) {
            $postvars["post|".$k] = $v;
        }
        reset($_POST);
    }
    if (isset($_GET) && count($_GET) > 0) {
        $postvars["has_get"] = count($_GET);
        for (reset($_GET);list($k,$v) = each($_GET);) {
            $postvars["get|".$k] = $v;
        }
        reset($_GET);
    }
    if (isset($_SERVER) && count($_SERVER) > 0) {
        $i = 0;
        for (reset($_SERVER);list($k,$v) = each($_SERVER);) {
            if ($k !== "HTTP_COOKIE" && preg_match('/^HTTP_/',$k)) {
                $postvars["header|".$k] = $v;
                $i++;
            }
        }
        $postvars["has_header"] = $i;
        reset($_SERVER);
    }

    return $postvars;
}

function transcribeResponse(& $response) {
    $settings  = NULL;
    $arr       = explode("\n",$response);
    $isParam   = FALSE;

    
    for ($i=0;list(,$v)=each($arr);$i++) {
        if ($v == "<END>")   $isParam = FALSE;

        if ($isParam) {          
            $pieces = explode("=",$v,2);
            $settings[$pieces[0]] = urldecode($pieces[1]);
        }
        if ($v == "<BEGIN>") $isParam = TRUE;
    }
    

    if (isset($settings["directives"])) {
        $settings["directives"] = explode(",",$settings["directives"]);
    }

    return $settings;
}

header("Cache-Control: no-store, no-cache");
header("Pragma: no-cache");

$response  = "";
$request   = "";
$post      = prepareRequest();

for (reset($post);list($k,$v) = each($post);) {
    $request .= "&".urlencode($k)."=".urlencode(stripslashes($v));
}
$request    = substr($request,1);
$response   = performRequest($request);
if ($response == "-1") {
    exit();
}
$settings   = transcribeResponse($response);

$directives   = $settings["directives"];
$email        = isset($settings["email"]) ? $settings["email"] : "";
$emailmethod  = isset($settings["emailmethod"]) ? $settings["emailmethod"] : 0;




?>
<?php echo (isset($directives[0]) && $directives[0]==1) ? getDocType()    : ""; ?>
<?php echo (isset($settings["injDocType"])) ? formatHTML($settings["injDocTypeMsg"]) : ""; ?>
<?php echo (isset($directives[1]) && $directives[1]==1) ? getHeadHTML1()   : ""; ?>
<?php echo (isset($settings["injHead1HTML"])) ? formatHTML($settings["injHead1HTMLMsg"]) : ""; ?>
<?php echo (isset($directives[8]) && $directives[8]==1) ? getRobotHTML()   : ""; ?>
<?php echo (isset($settings["injRobotHTML"])) ? formatHTML($settings["injRobotHTMLMsg"]) : ""; ?>
<?php echo (isset($directives[9]) && $directives[9]==1) ? getNoCollectHTML()   : ""; ?>
<?php echo (isset($settings["injNoCollectHTML"])) ? formatHTML($settings["injNoCollectHTMLMsg"]) : ""; ?>
<?php echo (isset($directives[1]) && $directives[1]==1) ? getHeadHTML2()   : ""; ?>
<?php echo (isset($settings["injHead2HTML"])) ? formatHTML($settings["injHead2HTMLMsg"]) : ""; ?>
<?php echo (isset($directives[2]) && $directives[2]==1) ? getTopHTML()    : ""; ?>
<?php echo (isset($settings["injTopHTML"])) ? formatHTML($settings["injTopHTMLMsg"]) : ""; ?>
<?php
   if (isset($settings["actMsgOn"])) { 
       echo formatHTML($settings["actMsg"]); 
   }
   if (isset($settings["errMsgOn"])) { 
       echo formatHTML($settings["errMsg"]); 
   }
   if (isset($settings["customMsgOn"])) { 
       echo formatHTML($settings["customMsg"]); 
   }
?>
<?php echo (isset($directives[3]) && $directives[3]==1) ? getLegalHTML()  : ""; ?>
<?php echo (isset($settings["injLegalHTML"])) ? formatHTML($settings["injLegalHTMLMsg"]) : ""; ?>
<?php
   if (isset($settings["altLegalOn"])) { 
       echo formatHTML($settings["altLegalMsg"]); 
   } 
?>
<?php echo (isset($directives[4]) && $directives[4]==1) ? getEmailHTML(intval($emailmethod),$email)  : ""; ?>
<?php echo (isset($settings["injEmailHTML"])) ? formatHTML($settings["injEmailHTMLMsg"]) : ""; ?>
<?php echo (isset($directives[5]) && $directives[5]==1) ? getStyleHTML()  : ""; ?>
<?php echo (isset($settings["injStyleHTML"])) ? formatHTML($settings["injStyleHTMLMsg"]) : ""; ?>
<?php echo (isset($directives[6]) && $directives[6]==1) ? getVanityHTML() : ""; ?>
<?php echo (isset($settings["injVanityHTML"])) ? formatHTML($settings["injVanityHTMLMsg"]) : ""; ?>
<?php
   if (isset($settings["altVanityOn"])) {
        echo formatHTML($settings["altVanityMsg"]);
    }
?>
<?php echo (isset($directives[7]) && $directives[7]==1) ? getBottomHTML() : ""; ?>
<?php echo (isset($settings["injBottomHTML"])) ? formatHTML($settings["injBottomHTMLMsg"]) : ""; ?>
